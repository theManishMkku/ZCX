# ZCX
All-in-one creator toolkit (Android): **Captions**, **Shorts cutter**, **Upscaler**. 100% on-device, free.

## APK kaise banaye (phone se)
1. Repo GitHub pe push/upload karo (main branch)
2. Actions tab -> "Build ZCX APK" -> Run workflow
3. Run khatam hone pe Artifacts -> ZCX-apk download -> install
